package com.cg.fms.test;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.fms.dto.Employee;
import com.cg.fms.exception.FMSException;
import com.cg.fms.service.EmployeeService;
import com.cg.fms.service.EmployeeServiceImpl;




public class EmployeeServiceTest {
	static EmployeeService fsImpl = null;
	
	@BeforeClass
	public static void initClass() {
		fsImpl = new EmployeeServiceImpl();
	}
	
	@Test
	public void EmployeeLoginTest1() {
		 Employee emp = null;
		try {
			emp = fsImpl.login(10002, "rohit");
		} catch (FMSException e) {
		}
		Assert.assertNotNull(emp);
	}
	
	@Test
	public void EmployeeLoginTest2() {
		 Employee emp = null;
		try {
			emp = fsImpl.login(10003, "rohit");
		} catch (FMSException e) {
		}
		Assert.assertNull(emp);
	}

}
