package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.fms.dto.Course;
import com.cg.fms.dto.ParticipantEnrollment;
import com.cg.fms.exception.FMSException;
import com.cg.fms.util.ApplicationLogger;
import com.cg.fms.util.DBUtil;

public class ParticipantEnrollmentDaoImpl implements ParticipantEnrollmentDao {

	Connection con;
	Logger participantLogger = null;

	public ParticipantEnrollmentDaoImpl() {
		super();
		con = DBUtil.getConnection();

		participantLogger = ApplicationLogger.getLogger(ParticipantEnrollmentDaoImpl.class);
	}

	//This method returns all participant enrollment
	@Override
	public ArrayList<ParticipantEnrollment> getAllParticipantEnrollments() throws FMSException {
		ArrayList<ParticipantEnrollment> participantEnrollmentList = new ArrayList<ParticipantEnrollment>();
		String query = "SELECT * FROM participant_enrollment";
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(query);
			participantLogger.info("Fetch All Participants");
			while (rs.next()) {
				participantEnrollmentList.add(new ParticipantEnrollment(rs.getInt(1), rs.getInt(2)));
			}
		} catch (SQLException e) {
			throw new FMSException(e.getMessage());
		}

		return participantEnrollmentList;
	}
	
	//This method adds participant enrollment in database
	@Override
	public ParticipantEnrollment addParticipantEnrollment(ParticipantEnrollment participantEnrollment)
			throws FMSException {
		String query = "INSERT INTO participant_enrollment values(?,?)";
		ParticipantEnrollment ref = null;
		try {
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, participantEnrollment.getTrainingCode());
			ps.setInt(2, participantEnrollment.getParticipantId());
			int updatedRows = ps.executeUpdate();
			participantLogger.info("Data Inserted in ParticipantEnrollment");
			if (updatedRows > 0) {
				ref = participantEnrollment;
			}
		} catch (SQLException e) {
			throw new FMSException(e.getMessage());
		}
		return ref;
	}

	//This method returns participant enrollment from participant id
	@Override
	public ArrayList<ParticipantEnrollment> getParticipantEnrollmentByParticipantId(int id) throws FMSException {
		ArrayList<ParticipantEnrollment> participantEnrollmentList = new ArrayList<ParticipantEnrollment>();
		String query = "SELECT * FROM participant_enrollment where participant_id=?";
		try {
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			participantLogger.info("Fetch Partcipant details for ParticiapntId= " + id);
			while (rs.next()) {
				participantEnrollmentList.add(new ParticipantEnrollment(rs.getInt(1), rs.getInt(2)));
			}
		} catch (SQLException e) {
			throw new FMSException(e.getMessage());
		}

		return participantEnrollmentList;
	}
	
	//This method returns participant enrollment from training id
	@Override
	public ArrayList<ParticipantEnrollment> getParticipantEnrollmentByTrainingId(int id) throws FMSException {
		ArrayList<ParticipantEnrollment> participantEnrollmentList = new ArrayList<ParticipantEnrollment>();
		String query = "SELECT * FROM participant_enrollment where training_code=?";
		try {
			PreparedStatement ps = con.prepareStatement(query);
			participantLogger.info("Fetch Partcipant details for TrainingCode= " + id);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				participantEnrollmentList.add(new ParticipantEnrollment(rs.getInt(1), rs.getInt(2)));
			}
		} catch (SQLException e) {
			throw new FMSException(e.getMessage());
		}

		return participantEnrollmentList;
	}

}
