package com.cg.fms.service;

import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.cg.fms.dao.CourseDaoImpl;
import com.cg.fms.dao.EmployeeDao;
import com.cg.fms.dao.EmployeeDaoImpl;
import com.cg.fms.dto.Employee;
import com.cg.fms.exception.FMSException;
import com.cg.fms.util.ApplicationLogger;

public class EmployeeServiceImpl implements EmployeeService {

	EmployeeDao dao;
	Logger empLogger;

	public EmployeeServiceImpl() {
		dao = new EmployeeDaoImpl();
		empLogger = ApplicationLogger.getLogger(EmployeeServiceImpl.class);
	}

	@Override
	public Employee getEmployeeById(int id) throws FMSException {
		// TODO Auto-generated method stub
		return dao.getEmployeeById(id);
	}

	@Override
	public ArrayList<Employee> getAllEmployees() throws FMSException {
		// TODO Auto-generated method stub
		return dao.getAllEmployees();
	}

	@Override
	public Employee addEmployee(Employee emp) throws FMSException {
		// TODO Auto-generated method stub
		return dao.addEmployee(emp);
	}

	@Override
	public Employee updateEmployee(Employee emp) throws FMSException {
		// TODO Auto-generated method stub
		return dao.updateEmployee(emp);
	}

	@Override
	public boolean deleteEmployee(int id) throws FMSException {
		// TODO Auto-generated method stub
		return dao.deleteEmployee(id);
	}

	@Override
	public Employee getEmployeeByName(String name) throws FMSException {
		// TODO Auto-generated method stub
		return dao.getEmployeeByName(name);
	}

	@Override
	public boolean validateId(int id) {
		// System.out.println("empId div" + id/10000);
		if (id != 0 && id / 10000 >= 1 && id / 10000 <= 9)

		{
			empLogger.info("EmployeeId validated");
			return true;

		} else {
			empLogger.error("EmployeeId invalid");
			return false;
		}
	}

	@Override
	public Employee login(int employeeId, String password) throws FMSException {
		Employee employee = getEmployeeById(employeeId);
		if (employee == null) {
			return employee;
		}
		if (!employee.getPassword().equals(password)) {
			return null;
		}
		return employee;
	}

}
